function redirectPage(){
  window.location = "https://www.w3schools.com"
 }
setTimeout('redirectPage()',4000);